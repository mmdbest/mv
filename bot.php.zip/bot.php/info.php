<?php 

$token="5230240313:AAF8lbWXhk5h7eV04bZUP8MkO7L9sUyfkNA";//توکن رباتی که میخوای بیاد بالا

$id=1944893359;
$apikey="AAAAX_KQbhs:APA91bHH0zdtL-OgkOKCgJZ9bR00PMGOB0jjLDRUW80qOetlMGAXO5upXAVKQxhEzt8xs0OudIggUWdDyBaQzTjNdfFBvu59Nr0KGpSzjmYg1wZBCPMAiNHS0D9hXo92cplzGtMVF66J";//Server Key فایربیس

$admin_list=[0];//ایدی عددی خودت یا گروهی که ربات توش ادمینه و میخوای بیاد بالا

?>